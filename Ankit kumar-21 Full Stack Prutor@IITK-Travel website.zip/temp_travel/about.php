<!DOCTYPE php>
<php lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

  
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <link rel="stylesheet" href="css/style.css">
  
   <script src="https://kit.fontawesome.com/5fa4a39f27.js" crossorigin="anonymous"></script>

   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

</head>
<body>

<section class="header">

   <a href="home.php" class="logo navbar-brand">Ghumoo</a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php">package</a>
      <a href="book.php">book</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>



<div class="heading" style="background:url(images/heading.png) no-repeat">
   <h1 class=" text-white fw-bold "><em>Dream Holidays</em></h1>
</div>

<hr class="breaker">

<section class="about">

   <div class="image">
      <img src="images/about-img.jpg" class="shadow-lg " alt="">
   </div>

   <div class="content">
      <h3>why choose us?</h3>
      <p>Since 2001, ‘Ghumoo’ has been focused on bringing our customers the best in esteem and quality travel game plans. We are enthusiastic about movement and sharing the world’s marvels on 
         the ‘Ghumoo’</p>
      <p>Our motivating force is to turn your vacation into a memorable experience. We work hard to be a part of your happy journey.</p>
      <p>we love discovering new places with you. We offer tours and activities in different parts of the world so that you always feel close to us.</p>
      <p>We know that no destination or two travelers are the same. We offer different types of tours so you can find what you are looking for.</p>
      <p>Whether you are planning for an adventure travel getaway, wedding, honeymoon or babymoon, a family vacation at the beach, a safari,  luxury river cruise, luxury ocean cruise, wellness retreat at an exotic destination, group or corporate travel, We are dedicated to understanding your travel needs and expectations and we’re motivated to insure you achieve them. Call us today to begin planning the trip of a lifetime!</p>
      <div class="icons-container shadow">
         <div class="icons">
            <i class="fa-solid fa-map-pin"style="color:blue"></i>
            <span>top destinations</span>
         </div>
         <div class="icons shadow">
            <i class="fas fa-hand-holding-usd" style="color:blue"></i>
            <span>affordable price</span>
         </div>
         <div class="icons shadow">
            <i class="fas fa-headset" style="color:red"></i>
            <span>24/7 guide service</span>
         </div>
      </div>
   </div>

</section>

<section class="reviews">

   <h1 class="heading-title display-3"> clients reviews </h1>

   <div class="swiper reviews-slider">

      <div class="swiper-wrapper">

         <div class="swiper-slide slide">
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>The arrangements were organised swiftly and efficiently and the trip went smoothly. Great customer service and good communication throughout! Highly recommend.</p>
            <h3>Amulya Awasthi</h3>
            <span>traveler</span>
            <img src="images/pic-1.png" alt="">
         </div>

         <div class="swiper-slide slide">
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>My experience was amazing. It was totally worth it. I don't regret a single penny I paid. Management was super good and the staff was cooperative as well. They made sure that client's are satisfied or not. Whatever we decided on, everything was included in the package.</p>
            <h3>Parul lawaniya</h3>
            <span>traveler</span>
            <img src="images/pic-2.png" alt="">
         </div>

         <div class="swiper-slide slide">
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>Economical and affordable tour packages backed by top priority services. I would highly recommend Tourwithme as I have personally experienced the service quality. Kudos to the team !!</p>
            <h3>Ankit Kumar</h3>
            <span>traveler</span>
            <img src="images/pic-3.png" alt="">
         </div>

         <div class="swiper-slide slide">
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>The arrangements were organised swiftly and efficiently and the trip went smoothly. Great customer service and good communication throughout! Highly recommend.</p>
            <h3>Tanya Mishra</h3>
            <span>traveler</span>
            <img src="images/pic-4.png" alt="">
         </div>

         
         <div class="swiper-slide slide">
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>My experience was amazing. It was totally worth it. I don't regret a single penny I paid. Management was super good and the staff was cooperative as well. They made sure that client's are satisfied or not. Whatever we decided on, everything was included in the package.</p>
            <h3>Preet kaur</h3>
            <span>traveler</span>
            <img src="images/pic-2.png" alt="">
         </div>

         
         <div class="swiper-slide slide">
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>My experience was amazing. It was totally worth it. I don't regret a single penny I paid. Management was super good and the staff was cooperative as well. They made sure that client's are satisfied or not. Whatever we decided on, everything was included in the package.</p>
            <h3>Shobha Shusodia</h3>
            <span>traveler</span>
            <img src="images/pic-2.png" alt="">
         </div>

      </div>

   </div>

</section>
<hr>
<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +918382025751 </a>
         <a href="#"> <i class="fas fa-envelope"></i> itsankitt231@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i>Noida,India </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
      </div>

   </div>

   

</section>

<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>


<script src="js/script.js"></script>

</body>
</php>